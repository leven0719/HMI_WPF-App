﻿using System.Windows;
using System.Windows.Threading;
using System;
using System.ComponentModel;

namespace _7SegmentLed
{
    public partial class MainWindow : Window,INotifyPropertyChanged
    {
        #region Public properties

        private int homePoints;
        public int HomePoints 
        {
            get {return homePoints; }
            set
            { 
                homePoints = value;
                this.OnPropertyChanged("HomePoints");
            }
        }

        public int visitorPoints;
        public int VisitorPoints
        {
            get { return visitorPoints; }
            set
            { 
                visitorPoints = value;
                this.OnPropertyChanged("VisitorPoints");
            }
        }

        public DateTime timer;
        public DateTime Timer 
        {
            get { return timer; }
            set
            {
                timer = value;
                this.OnPropertyChanged("Timer");
            }
        }

        #endregion

        public MainWindow()
        {
            InitializeComponent();
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(1000);
            timer.Tick += new EventHandler(TimerEventHandler);
            timer.Start();
            this.DataContext = this;    //bind all user interface to this class
            TimerEventHandler(null, null);
        }

        private void TimerEventHandler(Object sender, EventArgs args)
        {
            Timer = DateTime.Now;
            VisitorPoints++;
            HomePoints++;
        }

        #region INotifyPropertyChanged members

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                this.PropertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}




